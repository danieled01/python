dict = {}
x = 0

while x < 0:
    name = input("Name = ")
    surname = input("Surname = ")
    dict[name]=surname
    x+=1



print (dict)
