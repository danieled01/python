x = float(input("First Number: "))
y = float(input("Second Number: "))

def addition(x,y):
    return x+y

print ("We always add 20 to your numbers ", addition(x,y) + 20) 

