with open("example.txt", "w") as myfile:
    myfile.write("Dan D'Amico\n")
