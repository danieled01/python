def divide(a,b):
    try:
        return a/b
    except ZeroDivisionError:
        return "Zero division doesnt make sense"

print(divide(1,0))
