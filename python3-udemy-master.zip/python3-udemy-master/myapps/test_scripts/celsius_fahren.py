x = float(input("Please enter the Celsius you wish to convert: "))

def cel2far(cel):
    return cel * 9/5 +32

print(cel2far(x))
