euro = input("Euro value = ")
pound = input("How much you want to convert = ")

def pound_to_euro(pound):
    total = pound * float(euro)
    return total

print(pound_to_euro(float(pound)))
