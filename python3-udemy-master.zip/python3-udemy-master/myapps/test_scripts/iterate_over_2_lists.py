mylista = ['a','b','c']
mylist1 = [1,2,3]

for itema, item1 in zip(mylista,mylist1):
    print("%s is %s" %(itema,item1))
