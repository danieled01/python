dict = {}

letter = ["a","b","c","d","e","f","g","h","i"]
number = 0

for i in letter:
    dict[number]=letter[number]
    number+=1

print (dict)
