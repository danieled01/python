x = 0

while x < 3:
    print("x is now at value", x,"thefore smaller than 3.")
    x = x + 1
