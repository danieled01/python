user_name = "Dan"
user_surname = "D'Amico"
print("Hello", user_name, "how are you?")
username = "Hello", user_name, "how are you?"
print(username)

username_sf = "Hello %s %s how are you?" % (user_name,user_surname)
print(username_sf)
