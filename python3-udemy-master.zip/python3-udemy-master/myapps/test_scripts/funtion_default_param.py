def greeting(message="Good Morning", name="Dan"):
    return message, name

print(greeting())

x = "Good Afternoon"
y = "John"

print(greeting(x,y))
