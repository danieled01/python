def minutes_to_hours(minutes):
    hours = minutes /60
    return hours

print (minutes_to_hours(35))
