#useful example of how continue works
a=1

while True:
    if a == 1:
        print('a')
        continue
    print('b')
